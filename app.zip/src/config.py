"""
SR Impact Navigator+ 설정 파일
"""
import os
from dotenv import load_dotenv

# 환경 변수 로드
# 현재 디렉토리와 상위 디렉토리에서 .env 파일 찾기
config_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(config_dir, '.env'))
load_dotenv()  # 현재 작업 디렉토리에서도 로드

class Config:
    """애플리케이션 설정"""
    
    # Azure AI Search 설정
    AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://your-search-service.search.windows.net")
    AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY", "your-search-key")
    AZURE_SEARCH_INDEX_SR = "sr-index"
    AZURE_SEARCH_INDEX_INCIDENT = "incident-index"
    
    # Azure OpenAI 설정 (텍스트 생성용)
    AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-openai-service.openai.azure.com")
    AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY", "your-openai-key")
    AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4")
    
    # Azure OpenAI 설정 (텍스트 생성용 - 별도 리소스)
    AZURE_TEXT_OPENAI_ENDPOINT = os.getenv("AZURE_TEXT_OPENAI_ENDPOINT", "https://your-openai-service.openai.azure.com")
    AZURE_TEXT_OPENAI_KEY = os.getenv("AZURE_TEXT_OPENAI_KEY", "your-openai-key")
    AZURE_TEXT_OPENAI_DEPLOYMENT = os.getenv("AZURE_TEXT_OPENAI_DEPLOYMENT", "gpt-4")
    
    # Azure OpenAI 설정 (임베딩용 - 별도 리소스)
    AZURE_EMBEDDING_OPENAI_ENDPOINT = os.getenv("AZURE_EMBEDDING_OPENAI_ENDPOINT", "https://your-embedding-service.openai.azure.com")
    AZURE_EMBEDDING_OPENAI_KEY = os.getenv("AZURE_EMBEDDING_OPENAI_KEY", "your-embedding-key")
    AZURE_EMBEDDING_OPENAI_DEPLOYMENT = os.getenv("AZURE_EMBEDDING_OPENAI_DEPLOYMENT", "text-embedding-3-small")

    # 리스크 계산 가중치
    RISK_WEIGHTS = {
        "sr_similarity": 0.25,
        "incident_correlation": 0.25,
        "system_importance": 0.25,
        "time_sensitivity": 0.15,
        "sr_complexity": 0.10
    }
    
    # 리스크 등급 임계값
    RISK_THRESHOLDS = {
        "critical": 0.8,
        "high": 0.6,
        "medium": 0.4,
        "low": 0.2
    }
    
    # 시스템 중요도 등급
    SYSTEM_IMPORTANCE_LEVELS = {
        "Critical": 1.0,
        "High": 0.8,
        "Medium": 0.6,
        "Low": 0.4,
        "Minimal": 0.2
    }
